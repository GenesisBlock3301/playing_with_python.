def trail(number):
    print("This is a function")
    return number

