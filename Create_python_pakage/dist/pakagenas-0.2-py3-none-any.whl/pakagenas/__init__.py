class Trail:
    def __init__(self):
        print("Constructor Done")

    def trail(number):
        print("This is a function")
        return number
