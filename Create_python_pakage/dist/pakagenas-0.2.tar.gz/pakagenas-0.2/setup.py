from setuptools import setup, find_packages

setup(
    name="pakagenas",
    version="0.2",
    description="This is code with hurry package",
    long_description="This is a very very long description",
    author="nas-tech",
    packages=["pakagenas"],
    install_requires=[],
)
